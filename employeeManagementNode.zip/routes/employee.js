var express = require('express');
var router = express.Router();

var dbConn  = require('../config/mysqlConfig');

/* GET - employee list */
router.get('/', function(req, res, next) {
  dbConn.query('SELECT * FROM employees', (err, data)=>{
    if(err){
        console.log('Error while fetching Employee List', err);
        res.json(err);
    }else{
        console.log('Employee List fetched successfully');
        res.json(data);
    }
  });
});

/* POST - new employee */
router.post('/', function(req, res, next) {
  // reading form data in req.body
  console.log(req.body); // should save it in db

  dbConn.query('INSERT INTO employees SET ? ', req.body, (err, data)=>{
    if(err){
      console.log('Error while inserting data');
      res.json(err);
    }else{
      console.log('Employee created successfully');
      res.json(data);
    }
  })

});

/* GET - employee details */
router.get('/:id', function(req, res, next) {
  console.log(req.params); // should save it in db

  dbConn.query('SELECT empid,empname,project,location FROM employees WHERE id=?', parseInt(req.params.id), (err, data)=>{
    if(err){
      console.log('Error while fetching data');
      res.json(err);
    }else{
      console.log('Employee fetched successfully');
      res.json(data);
    }
  })

});

/* PUT - edit employee details */
router.put('/:id', function(req, res, next) {
  console.log(req.params.id); 
  console.log(req.body); 

  dbConn.query("UPDATE employees SET empname=?,project=?,location=? WHERE id = ?", [req.body.empname,req.body.project,req.body.location, parseInt(req.params.id)], (err, data)=>{
    if(err){
      console.log('Error while updating data');
      res.json(err);
    }else{
      console.log('Employee updated successfully');
      res.json(data);
    }
  })
});

/* DELETE - edit employee details */
router.delete('/:id', function(req, res, next) {
    console.log(req.params.id); 
    console.log(req.body); 
  
    dbConn.query("DELETE FROM employees WHERE id = ?", parseInt(req.params.id), (err, data)=>{
      if(err){
        console.log('Error while deleting data');
        res.json(err);
      }else{
        console.log('Employee deleted successfully');
        res.json(data);
      }
    })
  });


module.exports = router;